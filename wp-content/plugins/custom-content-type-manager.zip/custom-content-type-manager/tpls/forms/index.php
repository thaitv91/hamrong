<?php
/* 
Silence is golden...

The files in this directory should use a .tpl extension.  They are intended to be referenced by the 
[cctm_post_form] shortcode via the _form parameter.
*/
?>