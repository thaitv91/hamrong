<div class="linklike" style="display:inline-block;">
	<img onclick="javascript:add_bulk_field('<?php print $data['type']; ?>');" src="<?php print $data['icon']; ?>" height="48" width="48" alt="<?php print $data['name']; ?>" title="<?php print $data['name']; ?>"/>
</div>